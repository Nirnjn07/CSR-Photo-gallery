from django.db import models

class LoginModel(models.Model):	
    id = models.AutoField(primary_key=True)
    cpfno = models.CharField(max_length=6)
    password = models.CharField(max_length=10)
    levl = models.CharField(max_length=2)
        	
    #class Meta:
        #managed = False
        #db_table = 'Tech_login'

    #def __str__(self):
        #return self.name	

# Create your models here.
