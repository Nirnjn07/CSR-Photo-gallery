from urllib import response
from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
#from smartetm.models import HouseinfoModel,EtmBlankFormModel,EtmmentryModel,EtmmentryoldModel,LoginModel
from datetime import datetime
#import xlwt



#import cx_Oracle
import calendar
import ast

def index(request):
    return render(request,'TECH/index.html')        
#-------------------------------------------------------------------------------------
# Create your views here.
def photo1_view(request):
    return render(request,'TECH/photo1.html')

def photo2_view(request):
    return render(request,'TECH/photo2.html')

def photo3_view(request):
    return render(request,'TECH/photo3.html')

def photo4_view(request):
    return render(request,'TECH/photo4.html')

def photo5_view(request):
    return render(request,'TECH/photo5.html')


